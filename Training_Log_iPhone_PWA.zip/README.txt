TRAINING LOG — iPhone PWA

Files:
- index.html
- manifest.json
- sw.js
- icon-192.png
- icon-512.png

To install on iPhone:
1. Upload this folder to a static HTTPS host (GitHub Pages is a good free option).
2. Open the resulting URL in Safari on your iPhone.
3. Tap Share -> Add to Home Screen -> Add.
4. Launch "Training" from your Home Screen.

Note: The current app is a schedule viewer. It does not yet save weights/reps or track completed sets.
